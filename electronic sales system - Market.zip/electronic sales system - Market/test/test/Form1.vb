﻿Imports System.Web

Public Class Form1


    Function fac(n As Double) As Double
        Dim fact As Double = 1
        For i = 1 To n
            fac *= i
        Next
        fac = fact
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim number As Double = 3
        Dim result As Double = fac(number)
        TextBox2.Text = result.ToString()
        fac(number)
    End Sub
End Class